#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Twist

def main():
    rospy.init_node('cmd_turtle')
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    

    rate = rospy.Rate(10) # 10hz
    cnt = 0
    while not rospy.is_shutdown():
        msg_vel = Twist()
        msg_vel.linear.x = 2.0
	msg_vel.angular.z = 3.0
	rospy.loginfo(msg_vel)	
	pub.publish(msg_vel)
	cnt += 1        
        rate.sleep()

if __name__ == '__main__':
    main()
